import React from "react"
import { Link, useLocation } from "react-router-dom"
import {
  BarChart3,
  Box,
  Tag,
  Settings2,
  Search,
  Package,
  Warehouse,
  DollarSign,
  Building2,
  Users,
  Globe,
  CheckCircle,
  FileText,
  ShoppingCart,
  Users2,
  TrendingUp,
  Zap,
  RotateCcw,
  Cog,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useTheme } from "./theme-provider"
import { Button } from "./ui/button"

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
}

interface NavGroup {
  group: string
  items: NavItem[]
}

const navGroups: NavGroup[] = [
  {
    group: "داشبورد",
    items: [{ label: "نمای کلی", href: "/dashboard", icon: <BarChart3 className="w-4 h-4" /> }],
  },
  {
    group: "کاتالوگ محصول",
    items: [
      { label: "محصولات", href: "/products", icon: <Box className="w-4 h-4" /> },
      { label: "دسته‌بندی", href: "/categories", icon: <Tag className="w-4 h-4" /> },
      { label: "برندها", href: "/brands", icon: <Settings2 className="w-4 h-4" /> },
      { label: "خصوصیات", href: "/attributes", icon: <Settings2 className="w-4 h-4" /> },
    ],
  },
  {
    group: "جستجو و فیلتر",
    items: [
      { label: "جستجوی پیشرفته", href: "/search", icon: <Search className="w-4 h-4" /> },
    ],
  },
  {
    group: "موجودی و انبار",
    items: [
      { label: "موجودی", href: "/inventory", icon: <Package className="w-4 h-4" /> },
      { label: "انبارها", href: "/warehouses", icon: <Warehouse className="w-4 h-4" /> },
      { label: "انتقالات", href: "/transfers", icon: <Warehouse className="w-4 h-4" /> },
    ],
  },
  {
    group: "قیمت‌گذاری",
    items: [
      { label: "لیست قیمت", href: "/pricing", icon: <DollarSign className="w-4 h-4" /> },
    ],
  },
  {
    group: "ساختار و سازمان",
    items: [
      { label: "شرکت‌ها", href: "/companies", icon: <Building2 className="w-4 h-4" /> },
      { label: "مشتریان", href: "/customers", icon: <Users className="w-4 h-4" /> },
      { label: "کانال‌های فروش", href: "/channels", icon: <Globe className="w-4 h-4" /> },
    ],
  },
  {
    group: "مدیریت سفارش",
    items: [
      { label: "تایید و ارزیابی", href: "/approvals", icon: <CheckCircle className="w-4 h-4" /> },
      { label: "درخواست قیمت", href: "/rfq", icon: <FileText className="w-4 h-4" /> },
      { label: "سفارش‌ها", href: "/orders", icon: <ShoppingCart className="w-4 h-4" /> },
    ],
  },
  {
    group: "پورتال نمایندگی",
    items: [
      { label: "نمایندگان", href: "/dealer-portal", icon: <Users2 className="w-4 h-4" /> },
    ],
  },
  {
    group: "تکمیل سفارش",
    items: [
      { label: "ارسال و تحویل", href: "/fulfillment", icon: <TrendingUp className="w-4 h-4" /> },
    ],
  },
  {
    group: "محتوا و CMS",
    items: [
      { label: "صفحات و بلاگ", href: "/cms", icon: <Zap className="w-4 h-4" /> },
    ],
  },
  {
    group: "مالی و حسابداری",
    items: [
      { label: "فاکتورها و پرداخت", href: "/finance", icon: <DollarSign className="w-4 h-4" /> },
    ],
  },
  {
    group: "گزارشات",
    items: [
      { label: "داشبورد‌های تحلیلی", href: "/reports", icon: <BarChart3 className="w-4 h-4" /> },
    ],
  },
  {
    group: "گسترش‌پذیری",
    items: [
      { label: "افزونه‌ها و سفارشی‌سازی", href: "/extensibility", icon: <Zap className="w-4 h-4" /> },
    ],
  },
  {
    group: "خدمات پس از فروش",
    items: [
      { label: "درخواست بازگشت", href: "/rma", icon: <RotateCcw className="w-4 h-4" /> },
    ],
  },
  {
    group: "تنظیمات",
    items: [
      { label: "تنظیمات سیستم", href: "/settings", icon: <Cog className="w-4 h-4" /> },
    ],
  },
]

export function Sidebar() {
  const location = useLocation()
  const { theme, setTheme } = useTheme()

  return (
    <aside className="w-64 bg-background border-r border-border h-screen overflow-y-auto flex flex-col" dir="rtl">
      <div className="p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-primary">B2B</h1>
        <p className="text-xs text-muted-foreground mt-1">پلتفرم تجارت الکترونیک</p>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-8">
        {navGroups.map((group) => (
          <div key={group.group}>
            <h3 className="px-2 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              {group.group}
            </h3>
            <div className="space-y-2">
              {group.items.map((item) => (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                    location.pathname === item.href
                      ? "bg-primary text-primary-foreground font-semibold"
                      : "hover:bg-accent text-foreground"
                  )}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-4 border-t border-border space-y-3">
        <div className="flex gap-2">
          <Button
            variant={theme === "light" ? "default" : "outline"}
            size="sm"
            onClick={() => setTheme("light")}
            className="flex-1"
          >
            روشن
          </Button>
          <Button
            variant={theme === "dark" ? "default" : "outline"}
            size="sm"
            onClick={() => setTheme("dark")}
            className="flex-1"
          >
            تاریک
          </Button>
        </div>
      </div>
    </aside>
  )
}
