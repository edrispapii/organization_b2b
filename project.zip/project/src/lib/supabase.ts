import { createClient } from "@supabase/supabase-js"

const supabaseUrl = (import.meta.env as any).VITE_SUPABASE_URL
const supabaseKey = (import.meta.env as any).VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseKey) {
  console.warn("Supabase URL or Key not configured. Some features may not work.")
}

export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseKey || "placeholder-key"
)
