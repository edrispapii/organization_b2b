import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { ThemeProvider } from "@/components/theme-provider"
import { Sidebar } from "@/components/sidebar"
import { Dashboard } from "@/pages/dashboard"
import { Products } from "@/pages/products"
import { Categories } from "@/pages/categories"
import { Brands } from "@/pages/brands"
import { Attributes } from "@/pages/attributes"
import { Search } from "@/pages/search"
import { Inventory } from "@/pages/inventory"
import { Warehouses } from "@/pages/warehouses"
import { Transfers } from "@/pages/transfers"
import { Pricing } from "@/pages/pricing"
import { Companies } from "@/pages/companies"
import { Customers } from "@/pages/customers"
import { Channels } from "@/pages/channels"
import { Approvals } from "@/pages/approvals"
import { RFQ } from "@/pages/rfq"
import { Orders } from "@/pages/orders"
import { DealerPortal } from "@/pages/dealer-portal"
import { Fulfillment } from "@/pages/fulfillment"
import { CMS } from "@/pages/cms"
import { Finance } from "@/pages/finance"
import { Reports } from "@/pages/reports"
import { Extensibility } from "@/pages/extensibility"
import { RMA } from "@/pages/rma"
import { Settings } from "@/pages/settings"

function AppContent() {
  return (
    <Router>
      <div className="flex h-screen" dir="rtl">
        <Sidebar />
        <main className="flex-1 overflow-auto bg-background">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/products" element={<Products />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/brands" element={<Brands />} />
            <Route path="/attributes" element={<Attributes />} />
            <Route path="/search" element={<Search />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/warehouses" element={<Warehouses />} />
            <Route path="/transfers" element={<Transfers />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/companies" element={<Companies />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/channels" element={<Channels />} />
            <Route path="/approvals" element={<Approvals />} />
            <Route path="/rfq" element={<RFQ />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/dealer-portal" element={<DealerPortal />} />
            <Route path="/fulfillment" element={<Fulfillment />} />
            <Route path="/cms" element={<CMS />} />
            <Route path="/finance" element={<Finance />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/extensibility" element={<Extensibility />} />
            <Route path="/rma" element={<RMA />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/" element={<Dashboard />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  )
}
