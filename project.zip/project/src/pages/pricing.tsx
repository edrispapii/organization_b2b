import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Pricing() {
  const priceLists = [
    { id: 1, name: "لیست قیمت خرد‌فروشی", currency: "تومان", products: "۲۳۰", active: true },
    { id: 2, name: "لیست قیمت عمده‌فروشی", currency: "تومان", products: "۲۰۰", active: true },
    { id: 3, name: "لیست قیمت نمایندگی", currency: "تومان", products: "۱۸۰", active: true },
    { id: 4, name: "لیست قیمت خاص", currency: "تومان", products: "۵۰", active: false },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">قیمت‌گذاری</h1>
        <p className="text-muted-foreground mt-1">مدیریت لیست‌های قیمت و ماتریس قیمت‌گذاری</p>
      </div>

      <Tabs defaultValue="lists" className="w-full">
        <TabsList>
          <TabsTrigger value="lists">لیست‌های قیمت</TabsTrigger>
          <TabsTrigger value="matrix">ماتریس قیمت</TabsTrigger>
          <TabsTrigger value="rules">قوانین تخفیف</TabsTrigger>
        </TabsList>

        <TabsContent value="lists">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {priceLists.map((list) => (
              <Card key={list.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{list.name}</CardTitle>
                    {list.active ? (
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">فعال</span>
                    ) : (
                      <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">غیرفعال</span>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">تعداد محصول:</span>
                    <span className="font-semibold">{list.products}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">واحد پول:</span>
                    <span>{list.currency}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="matrix">
          <Card>
            <CardHeader>
              <CardTitle>ماتریس قیمت</CardTitle>
            </CardHeader>
            <CardContent>
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-right py-2 px-4">محصول</th>
                    <th className="text-right py-2 px-4">خرد‌فروشی</th>
                    <th className="text-right py-2 px-4">عمده‌فروشی</th>
                    <th className="text-right py-2 px-4">نمایندگی</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-border">
                    <td className="py-2 px-4">محصول ۱</td>
                    <td className="py-2 px-4">۱۰۰۰</td>
                    <td className="py-2 px-4">۸۰۰</td>
                    <td className="py-2 px-4">۶۰۰</td>
                  </tr>
                  <tr className="border-b border-border">
                    <td className="py-2 px-4">محصول ۲</td>
                    <td className="py-2 px-4">۲۰۰۰</td>
                    <td className="py-2 px-4">۱۵۰۰</td>
                    <td className="py-2 px-4">۱۲۰۰</td>
                  </tr>
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules">
          <Card>
            <CardHeader>
              <CardTitle>قوانین تخفیف</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">تخفیف بر اساس مقدار خرید و دسته‌بندی</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
