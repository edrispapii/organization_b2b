import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"

export function RFQ() {
  const rfqs = [
    { id: 1, customer: "مشتری الف", items: "۵ محصول", validUntil: "۱۴۰۲/۱۰/۱۵", status: "در انتظار قیمت" },
    { id: 2, customer: "مشتری ب", items: "۳ محصول", validUntil: "۱۴۰۲/۱۰/۲۰", status: "قیمت داده شده" },
    { id: 3, customer: "مشتری ج", items: "۸ محصول", validUntil: "۱۴۰۲/۱۰/۲۵", status: "تایید شده" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">درخواست قیمت و نقل‌قول</h1>
        <p className="text-muted-foreground mt-1">مدیریت RFQ و پیشنهادات قیمتی</p>
      </div>

      <Tabs defaultValue="rfqs" className="w-full">
        <TabsList>
          <TabsTrigger value="rfqs">درخواست‌ها</TabsTrigger>
          <TabsTrigger value="quotes">نقل‌قول‌ها</TabsTrigger>
          <TabsTrigger value="analysis">تحلیل</TabsTrigger>
        </TabsList>

        <TabsContent value="rfqs">
          <Card>
            <CardHeader>
              <CardTitle>درخواست قیمت</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {rfqs.map((rfq) => (
                  <div key={rfq.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">RFQ #{rfq.id}</p>
                        <p className="text-sm text-muted-foreground">{rfq.customer}</p>
                        <p className="text-xs text-muted-foreground mt-1">{rfq.items}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground mb-2">معتبر تا: {rfq.validUntil}</p>
                        <Button size="sm">{rfq.status}</Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quotes">
          <Card>
            <CardHeader>
              <CardTitle>نقل‌قول‌های قیمتی</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {rfqs.filter(r => r.status !== "در انتظار قیمت").map((rfq) => (
                  <div key={rfq.id} className="border border-border rounded-lg p-4">
                    <p className="font-medium">Quote for RFQ #{rfq.id}</p>
                    <p className="text-sm text-muted-foreground">{rfq.customer}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis">
          <Card>
            <CardHeader>
              <CardTitle>تحلیل RFQ</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">تعداد RFQ</p>
                  <p className="text-2xl font-bold">۱۲</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">میانگین قیمت</p>
                  <p className="text-2xl font-bold">۵۰۰۰</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">نرخ تبدیل</p>
                  <p className="text-2xl font-bold">۶۵%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
