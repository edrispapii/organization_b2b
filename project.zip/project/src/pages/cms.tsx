import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"

export function CMS() {
  const pages = [
    { id: 1, title: "صفحه اصلی", type: "صفحه", status: "منتشر", views: "۵۰۰۰" },
    { id: 2, title: "درباره ما", type: "صفحه", status: "پیش‌نویس", views: "۲۰۰" },
    { id: 3, title: "محصولات جدید", type: "بلاگ", status: "منتشر", views: "۱۲۰۰" },
  ]

  const blogs = [
    { id: 1, title: "نکاتی درباره خرید آنلاین", author: "نویسنده ۱", date: "۱۴۰۲/۱۰/۱۰" },
    { id: 2, title: "راهنمای استفاده از سایت", author: "نویسنده ۲", date: "۱۴۰۲/۱۰/۸" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">مدیریت محتوا</h1>
          <p className="text-muted-foreground mt-1">مدیریت صفحات، بلاگ و SEO</p>
        </div>
        <Button>محتوای جدید</Button>
      </div>

      <Tabs defaultValue="pages" className="w-full">
        <TabsList>
          <TabsTrigger value="pages">صفحات</TabsTrigger>
          <TabsTrigger value="blog">بلاگ</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="pages">
          <Card>
            <CardHeader>
              <CardTitle>صفحات وب‌سایت</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">عنوان</th>
                      <th className="text-right py-3 px-4 font-semibold">نوع</th>
                      <th className="text-right py-3 px-4 font-semibold">وضعیت</th>
                      <th className="text-right py-3 px-4 font-semibold">بازدید</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pages.map((page) => (
                      <tr key={page.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{page.title}</td>
                        <td className="py-4 px-4">{page.type}</td>
                        <td className="py-4 px-4">
                          <span className={page.status === "منتشر" ? "text-green-600" : "text-orange-600"}>
                            {page.status}
                          </span>
                        </td>
                        <td className="py-4 px-4">{page.views}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blog">
          <Card>
            <CardHeader>
              <CardTitle>مقالات بلاگ</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {blogs.map((blog) => (
                  <div key={blog.id} className="border border-border rounded-lg p-4">
                    <p className="font-medium">{blog.title}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {blog.author} • {blog.date}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <CardTitle>بهینه‌سازی SEO</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Meta Title</label>
                <input className="w-full border border-border rounded px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Meta Description</label>
                <textarea className="w-full border border-border rounded px-3 py-2 text-sm" rows={3} />
              </div>
              <Button>ذخیره</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
