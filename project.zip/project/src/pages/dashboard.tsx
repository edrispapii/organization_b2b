import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts"

const areaData = [
  { name: "هفته ۱", sales: 4000 },
  { name: "هفته ۲", sales: 3000 },
  { name: "هفته ۳", sales: 2000 },
  { name: "هفته ۴", sales: 2780 },
  { name: "هفته ۵", sales: 1890 },
]

const pieData = [
  { name: "الکترونیک", value: 400 },
  { name: "لباس", value: 300 },
  { name: "غذایی", value: 300 },
  { name: "سایر", value: 200 },
]

const COLORS = ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b"]

export function Dashboard() {
  return (
    <div className="p-8 space-y-8" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold text-foreground">داشبورد</h1>
        <p className="text-muted-foreground mt-2">خوش آمدید به سیستم مدیریت B2B</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">کل فروش</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۱۲۳۴۵۶ تومان</p>
            <p className="text-xs text-muted-foreground mt-1">۲۰% افزایش از ماه قبل</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">تعداد سفارش</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۱۲۳۴</p>
            <p className="text-xs text-muted-foreground mt-1">۵% افزایش از ماه قبل</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">تعداد مشتری</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۵۶۷</p>
            <p className="text-xs text-muted-foreground mt-1">۱۵% افزایش از ماه قبل</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">موجودی</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۸۹۰</p>
            <p className="text-xs text-muted-foreground mt-1">SKU فعال</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>روند فروش</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={areaData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="sales" stroke="#8b5cf6" fill="#8b5cf6" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزیع محصولات</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>سفارش‌های اخیر</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div>
                  <p className="font-medium">سفارش #{1000 + i}</p>
                  <p className="text-sm text-muted-foreground">مشتری: شرکت {i}</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{50000 * i} تومان</p>
                  <p className="text-sm text-green-500">تکمیل شده</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
