import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Customers() {
  const [customers] = useState([
    { id: 1, name: "شرکت الف", type: "B2B", creditLimit: "۱۰۰۰۰۰", balance: "۲۰۰۰۰", status: "فعال" },
    { id: 2, name: "شرکت ب", type: "B2B", creditLimit: "۵۰۰۰۰", balance: "۸۰۰۰", status: "فعال" },
    { id: 3, name: "شرکت ج", type: "B2C", creditLimit: "۰", balance: "۰", status: "غیرفعال" },
  ])

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">مشتریان</h1>
          <p className="text-muted-foreground mt-1">مدیریت و نظارت بر مشتریان</p>
        </div>
        <Button>مشتری جدید</Button>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList>
          <TabsTrigger value="list">لیست مشتریان</TabsTrigger>
          <TabsTrigger value="groups">گروه‌های مشتری</TabsTrigger>
          <TabsTrigger value="analytics">تحلیل</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>مشتریان</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Input placeholder="جستجو..." />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">نام</th>
                      <th className="text-right py-3 px-4 font-semibold">نوع</th>
                      <th className="text-right py-3 px-4 font-semibold">سقف اعتباری</th>
                      <th className="text-right py-3 px-4 font-semibold">موجودی</th>
                      <th className="text-right py-3 px-4 font-semibold">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customers.map((customer) => (
                      <tr key={customer.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{customer.name}</td>
                        <td className="py-4 px-4">{customer.type}</td>
                        <td className="py-4 px-4">{customer.creditLimit}</td>
                        <td className="py-4 px-4">{customer.balance}</td>
                        <td className="py-4 px-4">
                          <span className={customer.status === "فعال" ? "text-green-600" : "text-red-600"}>
                            {customer.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="groups">
          <Card>
            <CardHeader>
              <CardTitle>گروه‌های مشتری</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 border border-border rounded-lg">
                  <p className="font-medium">VIP</p>
                  <p className="text-sm text-muted-foreground">۵ مشتری</p>
                </div>
                <div className="p-4 border border-border rounded-lg">
                  <p className="font-medium">عادی</p>
                  <p className="text-sm text-muted-foreground">۳۲ مشتری</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>تحلیل مشتریان</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">تحلیل‌های مشتری</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
