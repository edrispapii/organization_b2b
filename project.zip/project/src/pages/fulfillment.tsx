import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Fulfillment() {
  const shipments = [
    { id: 1, order: "۱۰۰۱", status: "دریافت شده", location: "انبار", eta: "۱۴۰۲/۱۰/۱۵" },
    { id: 2, order: "۱۰۰۲", status: "در حال حمل", location: "در راه", eta: "۱۴۰۲/۱۰/۱۲" },
    { id: 3, order: "۱۰۰۳", status: "تحویل شده", location: "مقصد", eta: "۱۴۰۲/۱۰/۱۰" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">تکمیل و تحویل سفارش</h1>
        <p className="text-muted-foreground mt-1">نظارت بر فرآیند حمل و تحویل</p>
      </div>

      <Tabs defaultValue="tracking" className="w-full">
        <TabsList>
          <TabsTrigger value="tracking">رهگیری</TabsTrigger>
          <TabsTrigger value="timeline">جدول زمانی</TabsTrigger>
        </TabsList>

        <TabsContent value="tracking">
          <Card>
            <CardHeader>
              <CardTitle>وضعیت حمل‌ونقل</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {shipments.map((shipment) => (
                  <div key={shipment.id} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="font-medium">سفارش #{shipment.order}</p>
                      <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {shipment.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <p className="text-muted-foreground">موقعیت: {shipment.location}</p>
                      <p className="text-muted-foreground">ETA: {shipment.eta}</p>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                      <div
                        className="bg-green-600 h-2 rounded-full"
                        style={{ width: `${shipment.status === "تحویل شده" ? "100%" : shipment.status === "در حال حمل" ? "60%" : "30%"}` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle>جدول زمانی ارسال</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {shipments.map((shipment, idx) => (
                  <div key={shipment.id} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div className="w-4 h-4 bg-primary rounded-full"></div>
                      {idx < shipments.length - 1 && <div className="w-0.5 h-16 bg-border"></div>}
                    </div>
                    <div>
                      <p className="font-medium">سفارش #{shipment.order}</p>
                      <p className="text-sm text-muted-foreground">{shipment.status}</p>
                      <p className="text-xs text-muted-foreground mt-1">{shipment.eta}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
