import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Upload } from "lucide-react"

export function Orders() {
  const [orders] = useState([
    { id: 1001, customer: "شرکت الف", total: "۵۰۰۰۰", items: "۵", status: "تکمیل شده" },
    { id: 1002, customer: "شرکت ب", total: "۲۵۰۰۰", items: "۳", status: "درحال انجام" },
    { id: 1003, customer: "شرکت ج", total: "۱۰۰۰۰۰", items: "۱۰", status: "در انتظار تایید" },
    { id: 1004, customer: "شرکت د", total: "۷۵۰۰۰", items: "۶", status: "ارسال شده" },
  ])

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">سفارش‌ها</h1>
          <p className="text-muted-foreground mt-1">مدیریت و نظارت بر سفارش‌های فروش</p>
        </div>
        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                سفارش جدید
              </Button>
            </DialogTrigger>
            <DialogContent dir="rtl">
              <DialogHeader>
                <DialogTitle>سفارش جدید سریع</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input placeholder="نام مشتری" />
                <Input placeholder="محصول" />
                <Input placeholder="مقدار" type="number" />
                <Button className="w-full">ایجاد سفارش</Button>
              </div>
            </DialogContent>
          </Dialog>
          <Button variant="outline" className="gap-2">
            <Upload className="w-4 h-4" />
            وارد CSV
          </Button>
        </div>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList>
          <TabsTrigger value="list">لیست سفارش‌ها</TabsTrigger>
          <TabsTrigger value="analytics">تحلیل</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            <CardContent className="pt-6">
              <div className="mb-4">
                <Input placeholder="جستجو سفارش..." />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">شماره</th>
                      <th className="text-right py-3 px-4 font-semibold">مشتری</th>
                      <th className="text-right py-3 px-4 font-semibold">کل</th>
                      <th className="text-right py-3 px-4 font-semibold">آیتم</th>
                      <th className="text-right py-3 px-4 font-semibold">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order) => (
                      <tr key={order.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">#{order.id}</td>
                        <td className="py-4 px-4">{order.customer}</td>
                        <td className="py-4 px-4">{order.total}</td>
                        <td className="py-4 px-4">{order.items}</td>
                        <td className="py-4 px-4">
                          <span className={
                            order.status === "تکمیل شده" ? "text-green-600" :
                            order.status === "ارسال شده" ? "text-blue-600" :
                            order.status === "درحال انجام" ? "text-orange-600" :
                            "text-gray-600"
                          }>
                            {order.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>تحلیل سفارش‌ها</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">تعداد سفارش</p>
                  <p className="text-2xl font-bold">۱۲۳۴</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">کل فروش</p>
                  <p className="text-2xl font-bold">۱۲M</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">میانگین</p>
                  <p className="text-2xl font-bold">۹.۷K</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">نرخ تکمیل</p>
                  <p className="text-2xl font-bold">۹۸%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
