import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function Categories() {
  const categories = [
    { id: 1, name: "الکترونیک", subcategories: ["کامپیوتر", "موبایل", "لوازم جانبی"] },
    { id: 2, name: "لباس و پوشاک", subcategories: ["مردانه", "زنانه", "بچگانه"] },
    { id: 3, name: "غذا و نوشیدنی", subcategories: ["لبنیات", "میوه‌جات", "دانه‌های روغنی"] },
    { id: 4, name: "کتاب و آموزش", subcategories: ["روان‌شناسی", "تاریخ", "علوم"] },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">دسته‌بندی محصولات</h1>
        <p className="text-muted-foreground mt-1">مدیریت دسته‌بندی‌ها و زیرشاخه‌ها</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>درخت دسته‌بندی</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {categories.map((category) => (
              <AccordionItem key={category.id} value={`cat-${category.id}`}>
                <AccordionTrigger>
                  <span className="font-medium">{category.name}</span>
                  <span className="text-sm text-muted-foreground mr-4">
                    ({category.subcategories.length} زیرشاخه)
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    {category.subcategories.map((sub, idx) => (
                      <div
                        key={idx}
                        className="py-2 px-4 bg-accent rounded-lg text-sm"
                      >
                        {sub}
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  )
}
