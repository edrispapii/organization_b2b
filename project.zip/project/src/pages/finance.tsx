import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Finance() {
  const invoices = [
    { id: "INV-001", customer: "مشتری الف", amount: "۵۰۰۰۰", dueDate: "۱۴۰۲/۱۰/۱۵", status: "پرداخت شده" },
    { id: "INV-002", customer: "مشتری ب", amount: "۲۵۰۰۰", dueDate: "۱۴۰۲/۱۰/۲۰", status: "درحال انتظار" },
    { id: "INV-003", customer: "مشتری ج", amount: "۱۰۰۰۰۰", dueDate: "۱۴۰۲/۱۰/۲۵", status: "سررسید" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">امور مالی</h1>
        <p className="text-muted-foreground mt-1">مدیریت فاکتورها، پرداخت‌ها و اعتبارات</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">کل فاکتورها</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۲۵۰M</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">پرداخت‌های معلق</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-orange-600">۵۰M</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">متأخر</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">۱۰M</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">سقف اعتباری</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۱۰۰M</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="invoices" className="w-full">
        <TabsList>
          <TabsTrigger value="invoices">فاکتورها</TabsTrigger>
          <TabsTrigger value="payments">پرداخت‌ها</TabsTrigger>
          <TabsTrigger value="credit">اعتبارات</TabsTrigger>
        </TabsList>

        <TabsContent value="invoices">
          <Card>
            <CardContent className="pt-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">شماره</th>
                      <th className="text-right py-3 px-4 font-semibold">مشتری</th>
                      <th className="text-right py-3 px-4 font-semibold">مبلغ</th>
                      <th className="text-right py-3 px-4 font-semibold">تاریخ سررسید</th>
                      <th className="text-right py-3 px-4 font-semibold">وضعیت</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((inv) => (
                      <tr key={inv.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{inv.id}</td>
                        <td className="py-4 px-4">{inv.customer}</td>
                        <td className="py-4 px-4">{inv.amount}</td>
                        <td className="py-4 px-4">{inv.dueDate}</td>
                        <td className="py-4 px-4">
                          <span className={
                            inv.status === "پرداخت شده" ? "text-green-600" :
                            inv.status === "سررسید" ? "text-red-600" :
                            "text-orange-600"
                          }>
                            {inv.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>ثبت پرداخت</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">مدیریت و ثبت پرداخت‌های دریافتی</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="credit">
          <Card>
            <CardHeader>
              <CardTitle>مدیریت سقف اعتباری</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">نظارت بر اعتبارات مشتریان</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
