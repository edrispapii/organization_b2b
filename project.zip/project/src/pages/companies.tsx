import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function Companies() {
  const companies = [
    { id: 1, name: "شرکت مادر", level: "۰", subsidiaries: ["شرکت الف", "شرکت ب"] },
    { id: 2, name: "شرکت الف", level: "۱", subsidiaries: ["واحد ۱", "واحد ۲"] },
    { id: 3, name: "شرکت ب", level: "۱", subsidiaries: [] },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">سازمان شرکت‌ها</h1>
        <p className="text-muted-foreground mt-1">مدیریت سلسله‌مراتب سازمانی</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>درخت سازمانی</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {companies.map((company) => (
              <AccordionItem key={company.id} value={`comp-${company.id}`}>
                <AccordionTrigger>
                  <span className="font-medium">{company.name}</span>
                  <span className="text-xs text-muted-foreground mr-4">
                    (سطح {company.level})
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  {company.subsidiaries.length > 0 ? (
                    <div className="space-y-2">
                      {company.subsidiaries.map((sub, idx) => (
                        <div key={idx} className="py-2 px-4 bg-accent rounded-lg text-sm mr-4">
                          {sub}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">بدون زیرشاخه</p>
                  )}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  )
}
