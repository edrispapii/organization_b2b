import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export function Extensibility() {
  const plugins = [
    { name: "درگاه پرداخت", status: "فعال", version: "۱.۲.۳" },
    { name: "پیامک‌رسانی", status: "فعال", version: "۲.۰.۰" },
    { name: "ایمیل", status: "غیرفعال", version: "۱.۰.۰" },
    { name: "حسابداری", status: "فعال", version: "۱.۵.۰" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">گسترش‌پذیری</h1>
        <p className="text-muted-foreground mt-1">مدیریت افزونه‌ها، فیلدهای سفارشی و جریان‌های کاری</p>
      </div>

      <Tabs defaultValue="plugins" className="w-full">
        <TabsList>
          <TabsTrigger value="plugins">افزونه‌ها</TabsTrigger>
          <TabsTrigger value="fields">فیلدهای سفارشی</TabsTrigger>
          <TabsTrigger value="workflows">جریان‌های کاری</TabsTrigger>
        </TabsList>

        <TabsContent value="plugins">
          <Card>
            <CardHeader>
              <CardTitle>افزونه‌های نصب شده</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {plugins.map((plugin, idx) => (
                  <div key={idx} className="border border-border rounded-lg p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium">{plugin.name}</p>
                      <p className="text-xs text-muted-foreground">v{plugin.version}</p>
                    </div>
                    <Badge variant={plugin.status === "فعال" ? "default" : "outline"}>
                      {plugin.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fields">
          <Card>
            <CardHeader>
              <CardTitle>فیلدهای سفارشی</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">تعریف فیلدهای سفارشی برای موجودیت‌ها</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workflows">
          <Card>
            <CardHeader>
              <CardTitle>جریان‌های کاری</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">ایجاد و مدیریت جریان‌های خودکار</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
