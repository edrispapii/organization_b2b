import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SearchIcon } from "lucide-react"

export function Search() {
  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">جستجوی پیشرفته</h1>
        <p className="text-muted-foreground mt-1">موتور جستجو و فیلتر‌گذاری محصولات</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>جستجو</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <SearchIcon className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <Input placeholder="جستجو محصول..." className="pl-10" />
            </div>
            <Button>جستجو</Button>
          </div>

          <Tabs defaultValue="filters" className="w-full">
            <TabsList>
              <TabsTrigger value="filters">فیلترها</TabsTrigger>
              <TabsTrigger value="synonyms">مترادفات</TabsTrigger>
              <TabsTrigger value="config">تنظیمات</TabsTrigger>
            </TabsList>

            <TabsContent value="filters" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">دسته‌بندی</label>
                  <select className="w-full border border-border rounded px-3 py-2">
                    <option>همه دسته‌بندی‌ها</option>
                    <option>الکترونیک</option>
                    <option>لباس</option>
                    <option>غذایی</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">برند</label>
                  <select className="w-full border border-border rounded px-3 py-2">
                    <option>همه برندها</option>
                    <option>سامسونگ</option>
                    <option>LG</option>
                    <option>Apple</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">حداقل قیمت</label>
                  <Input type="number" placeholder="0" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">حداکثر قیمت</label>
                  <Input type="number" placeholder="1000000" />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="synonyms" className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">افزودن مترادف</label>
                <div className="flex gap-2">
                  <Input placeholder="کلمه اول" />
                  <Input placeholder="کلمه دوم" />
                  <Button>افزودن</Button>
                </div>
              </div>
              <div className="border border-border rounded p-4">
                <p className="text-sm text-muted-foreground">مترادفات تعریف شده</p>
              </div>
            </TabsContent>

            <TabsContent value="config" className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">موتور جستجو</label>
                <select className="w-full border border-border rounded px-3 py-2">
                  <option>پیش‌فرض</option>
                  <option>Elasticsearch</option>
                  <option>Algolia</option>
                  <option>Custom</option>
                </select>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
