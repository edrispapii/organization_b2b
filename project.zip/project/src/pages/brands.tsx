import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Brands() {
  const brands = [
    { id: 1, name: "سامسونگ", products: "۱۲۳", category: "الکترونیک" },
    { id: 2, name: "LG", products: "۸۹", category: "الکترونیک" },
    { id: 3, name: "Nike", products: "۱۵۶", category: "لباس" },
    { id: 4, name: "Adidas", products: "۹۸", category: "لباس" },
    { id: 5, name: "Apple", products: "۶۷", category: "الکترونیک" },
    { id: 6, name: "Sony", products: "۴۵", category: "الکترونیک" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">برندها</h1>
        <p className="text-muted-foreground mt-1">مدیریت و نظارت بر برندهای محصول</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {brands.map((brand) => (
          <Card key={brand.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg">{brand.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">تعداد محصول:</span>
                <span className="font-semibold">{brand.products}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">دسته‌بندی:</span>
                <span className="text-sm">{brand.category}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
