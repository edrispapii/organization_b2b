import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Edit2, Trash2, Search } from "lucide-react"

export function Products() {
  const [products] = useState([
    { id: 1, name: "محصول ۱", category: "الکترونیک", price: "۵۰۰۰", stock: "۱۰۰" },
    { id: 2, name: "محصول ۲", category: "لباس", price: "۱۵۰۰", stock: "۵۰" },
    { id: 3, name: "محصول ۳", category: "غذایی", price: "۲۰۰۰", stock: "۲۰۰" },
    { id: 4, name: "محصول ۴", category: "الکترونیک", price: "۳۰۰۰", stock: "۷۵" },
  ])

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">محصولات</h1>
          <p className="text-muted-foreground mt-1">مدیریت کاتالوگ محصولات</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              افزودن محصول
            </Button>
          </DialogTrigger>
          <DialogContent dir="rtl">
            <DialogHeader>
              <DialogTitle>محصول جدید</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input placeholder="نام محصول" />
              <Input placeholder="دسته‌بندی" />
              <Input placeholder="قیمت" type="number" />
              <Input placeholder="موجودی" type="number" />
              <Button className="w-full">ذخیره</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
          <Input placeholder="جستجو محصولات..." className="pl-10" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>لیست محصولات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-right py-3 px-4 font-semibold">نام</th>
                  <th className="text-right py-3 px-4 font-semibold">دسته‌بندی</th>
                  <th className="text-right py-3 px-4 font-semibold">قیمت</th>
                  <th className="text-right py-3 px-4 font-semibold">موجودی</th>
                  <th className="text-center py-3 px-4 font-semibold">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id} className="border-b border-border hover:bg-accent">
                    <td className="py-4 px-4">{product.name}</td>
                    <td className="py-4 px-4">{product.category}</td>
                    <td className="py-4 px-4">{product.price} تومان</td>
                    <td className="py-4 px-4">{product.stock} عدد</td>
                    <td className="py-4 px-4">
                      <div className="flex gap-2 justify-center">
                        <Button variant="ghost" size="sm">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
