import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function DealerPortal() {
  const dealers = [
    { id: 1, name: "نماینده الف", type: "نمایندگی", region: "تهران", sales: "۲۵۰۰۰" },
    { id: 2, name: "نماینده ب", type: "فروشنده", region: "اصفهان", sales: "۱۵۰۰۰" },
    { id: 3, name: "نماینده ج", type: "تامین‌کننده", region: "شیراز", sales: "۳۰۰۰۰" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">پورتال نمایندگی</h1>
        <p className="text-muted-foreground mt-1">مدیریت نمایندگان، فروشندگان و تامین‌کنندگان</p>
      </div>

      <Tabs defaultValue="dealers" className="w-full">
        <TabsList>
          <TabsTrigger value="dealers">نمایندگان</TabsTrigger>
          <TabsTrigger value="performance">عملکرد</TabsTrigger>
          <TabsTrigger value="commissions">کمیسیون</TabsTrigger>
        </TabsList>

        <TabsContent value="dealers">
          <Card>
            <CardContent className="pt-6">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">نام</th>
                      <th className="text-right py-3 px-4 font-semibold">نوع</th>
                      <th className="text-right py-3 px-4 font-semibold">منطقه</th>
                      <th className="text-right py-3 px-4 font-semibold">فروش</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dealers.map((dealer) => (
                      <tr key={dealer.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{dealer.name}</td>
                        <td className="py-4 px-4">{dealer.type}</td>
                        <td className="py-4 px-4">{dealer.region}</td>
                        <td className="py-4 px-4">{dealer.sales}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>عملکرد نمایندگان</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">نمودارهای عملکرد فروش</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="commissions">
          <Card>
            <CardHeader>
              <CardTitle>محاسبه کمیسیون</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">محاسبه و نظارت بر کمیسیون‌ها</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
