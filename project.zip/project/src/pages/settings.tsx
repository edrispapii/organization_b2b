import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Settings() {
  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">تنظیمات</h1>
        <p className="text-muted-foreground mt-1">تنظیمات سیستم و پیکربندی</p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList>
          <TabsTrigger value="general">عمومی</TabsTrigger>
          <TabsTrigger value="channels">کانال‌ها</TabsTrigger>
          <TabsTrigger value="payment">شرایط پرداخت</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
          <TabsTrigger value="erp">ERP</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات عمومی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">نام شرکت</label>
                <Input defaultValue="شرکت تجارت الکترونیک" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">ایمیل تماس</label>
                <Input defaultValue="info@company.com" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">تلفن</label>
                <Input defaultValue="۰۲۱-۱۲۳۴-۵۶۷۸" />
              </div>
              <Button>ذخیره تغییرات</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="channels">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات کانال‌ها</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border border-border rounded-lg p-4">
                <p className="font-medium mb-3">کانال‌های فعال</p>
                <div className="space-y-2">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked />
                    <span>خرد‌فروشی آنلاین</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked />
                    <span>عمده‌فروشی</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" defaultChecked />
                    <span>نمایندگی</span>
                  </label>
                </div>
              </div>
              <Button>ذخیره</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment">
          <Card>
            <CardHeader>
              <CardTitle>شرایط پرداخت</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">موعد سررسید پیش‌فرض (روز)</label>
                <Input type="number" defaultValue="30" />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">سقف اعتباری پیش‌فرض</label>
                <Input type="number" defaultValue="1000000" />
              </div>
              <Button>ذخیره</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>مفاتیح API</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-accent rounded-lg border border-border">
                <p className="text-xs text-muted-foreground mb-1">API Key</p>
                <p className="font-mono text-sm break-all">sk_live_51234567890abcdefghijklmnop</p>
              </div>
              <Button>بازتولید مفتاح</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="erp">
          <Card>
            <CardHeader>
              <CardTitle>اتصال ERP</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">نوع ERP</label>
                <select className="w-full border border-border rounded px-3 py-2">
                  <option>انتخاب کنید</option>
                  <option>SAP</option>
                  <option>Oracle</option>
                  <option>NetSuite</option>
                  <option>سفارشی</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">URL سرور</label>
                <Input placeholder="https://erp.company.com" />
              </div>
              <Button>تست اتصال</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
