import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Approvals() {
  const approvals = [
    { id: 1, type: "سفارش", amount: "۵۰۰۰۰", requester: "فروشنده ۱", status: "منتظر تایید" },
    { id: 2, type: "تخفیف", amount: "۱۰%", requester: "فروشنده ۲", status: "تایید شده" },
    { id: 3, type: "سفارش بزرگ", amount: "۱۰۰۰۰۰۰", requester: "مشتری VIP", status: "در بررسی" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">جریان تایید و ارزیابی</h1>
        <p className="text-muted-foreground mt-1">نظارت بر تایید سفارش‌ها و درخواست‌ها</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>درخواست‌های منتظر تایید</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {approvals.map((approval) => (
              <div key={approval.id} className="border border-border rounded-lg p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium">{approval.type} #{approval.id}</p>
                  <p className="text-sm text-muted-foreground">
                    درخواست‌کننده: {approval.requester}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{approval.amount}</p>
                  <p className={`text-xs ${
                    approval.status === "تایید شده" ? "text-green-600" :
                    approval.status === "منتظر تایید" ? "text-orange-600" :
                    "text-blue-600"
                  }`}>
                    {approval.status}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">منتظر تایید</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">۵</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">تایید شده</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">۸۹</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">رد شده</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">۳</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
