import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"

export function Attributes() {
  const attributeGroups = [
    {
      id: 1,
      name: "رنگ",
      attributes: ["قرمز", "آبی", "سبز", "سیاه", "سفید"],
    },
    {
      id: 2,
      name: "سایز",
      attributes: ["XS", "S", "M", "L", "XL", "XXL"],
    },
    {
      id: 3,
      name: "مواد",
      attributes: ["پنبه", "ابریشم", "پلی‌استر", "لیکرا"],
    },
    {
      id: 4,
      name: "برند",
      attributes: ["ایرانی", "خارجی", "لاکچری"],
    },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">خصوصیات محصول</h1>
        <p className="text-muted-foreground mt-1">مدیریت گروه‌های خصوصیات و مقادیر</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>گروه‌های خصوصیات</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {attributeGroups.map((group) => (
              <AccordionItem key={group.id} value={`attr-${group.id}`}>
                <AccordionTrigger>
                  <span className="font-medium">{group.name}</span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="flex flex-wrap gap-2">
                    {group.attributes.map((attr, idx) => (
                      <Badge key={idx} variant="secondary">
                        {attr}
                      </Badge>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  )
}
