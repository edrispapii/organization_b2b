import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Inventory() {
  const inventoryData = [
    { warehouse: "انبار تهران", sku: "SKU001", quantity: "۲۰۰", reserved: "۵۰", available: "۱۵۰" },
    { warehouse: "انبار تهران", sku: "SKU002", quantity: "۱۵۰", reserved: "۳۰", available: "۱۲۰" },
    { warehouse: "انبار اصفهان", sku: "SKU001", quantity: "۱۰۰", reserved: "۲۰", available: "۸۰" },
    { warehouse: "انبار اصفهان", sku: "SKU003", quantity: "۳۰۰", reserved: "۱۰۰", available: "۲۰۰" },
    { warehouse: "انبار شیراز", sku: "SKU002", quantity: "۸۰", reserved: "۱۵", available: "۶۵" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">موجودی محصولات</h1>
        <p className="text-muted-foreground mt-1">نظارت بر موجودی در چند انبار</p>
      </div>

      <Tabs defaultValue="matrix" className="w-full">
        <TabsList>
          <TabsTrigger value="matrix">ماتریس موجودی</TabsTrigger>
          <TabsTrigger value="alerts">هشدارها</TabsTrigger>
        </TabsList>

        <TabsContent value="matrix">
          <Card>
            <CardHeader>
              <CardTitle>ماتریس موجودی چند انبار</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">انبار</th>
                      <th className="text-right py-3 px-4 font-semibold">SKU</th>
                      <th className="text-right py-3 px-4 font-semibold">مجموع</th>
                      <th className="text-right py-3 px-4 font-semibold">رزرو شده</th>
                      <th className="text-right py-3 px-4 font-semibold">در دسترس</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventoryData.map((item, idx) => (
                      <tr key={idx} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{item.warehouse}</td>
                        <td className="py-4 px-4 font-mono">{item.sku}</td>
                        <td className="py-4 px-4">{item.quantity}</td>
                        <td className="py-4 px-4 text-orange-600">{item.reserved}</td>
                        <td className="py-4 px-4 text-green-600">{item.available}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts">
          <Card>
            <CardHeader>
              <CardTitle>هشدارهای موجودی</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 border border-orange-200 bg-orange-50 rounded-lg">
                  <p className="font-medium text-orange-900">موجودی کم: SKU001</p>
                  <p className="text-sm text-orange-700">انبار تهران تنها ۱۵۰ عدد در انبار دارد</p>
                </div>
                <div className="p-4 border border-red-200 bg-red-50 rounded-lg">
                  <p className="font-medium text-red-900">موجودی منفی: SKU005</p>
                  <p className="text-sm text-red-700">سفارش‌های رزرو شده بیش از موجودی</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
