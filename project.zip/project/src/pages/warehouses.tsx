import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export function Warehouses() {
  const warehouses = [
    { id: 1, name: "انبار تهران", location: "تهران", capacity: "۵۰۰۰", used: "۳۲۰۰" },
    { id: 2, name: "انبار اصفهان", location: "اصفهان", capacity: "۳۰۰۰", used: "۱۸۰۰" },
    { id: 3, name: "انبار شیراز", location: "شیراز", capacity: "۲۰۰۰", used: "۹۵۰" },
    { id: 4, name: "انبار مشهد", location: "مشهد", capacity: "۴۰۰۰", used: "۲۵۰۰" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">انبارها</h1>
          <p className="text-muted-foreground mt-1">مدیریت مراکز توزیع و انبارها</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          انبار جدید
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {warehouses.map((warehouse) => (
          <Card key={warehouse.id}>
            <CardHeader>
              <CardTitle>{warehouse.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">موقعیت:</span>
                <span>{warehouse.location}</span>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">ظرفیت</span>
                  <span className="text-sm">{warehouse.used}/{warehouse.capacity}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full"
                    style={{ width: `${(parseInt(warehouse.used) / parseInt(warehouse.capacity)) * 100}%` }}
                  ></div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1">ویرایش</Button>
                <Button variant="outline" className="flex-1">مشاهده</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
