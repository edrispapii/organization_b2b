import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Transfers() {
  const transfers = [
    { id: 1, from: "انبار تهران", to: "انبار اصفهان", items: "۵۰", status: "تکمیل شده" },
    { id: 2, from: "انبار اصفهان", to: "انبار شیراز", items: "۳۰", status: "درحال انتقال" },
    { id: 3, from: "انبار مشهد", to: "انبار تهران", items: "۱۰۰", status: "در انتظار تایید" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">انتقالات بین انبارها</h1>
        <p className="text-muted-foreground mt-1">مدیریت انتقال موجودی بین مراکز</p>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList>
          <TabsTrigger value="active">انتقالات فعال</TabsTrigger>
          <TabsTrigger value="completed">تکمیل شده</TabsTrigger>
          <TabsTrigger value="history">تاریخچه</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {transfers.filter(t => t.status !== "تکمیل شده").map((transfer) => (
                  <div key={transfer.id} className="border border-border rounded-lg p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium">#{transfer.id}</p>
                      <p className="text-sm text-muted-foreground">
                        از {transfer.from} به {transfer.to}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{transfer.items} عدد</p>
                      <p className="text-xs text-blue-600">{transfer.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {transfers.filter(t => t.status === "تکمیل شده").map((transfer) => (
                  <div key={transfer.id} className="border border-border rounded-lg p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium">#{transfer.id}</p>
                      <p className="text-sm text-muted-foreground">
                        از {transfer.from} به {transfer.to}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{transfer.items} عدد</p>
                      <p className="text-xs text-green-600">{transfer.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground">تاریخچه انتقالات</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
