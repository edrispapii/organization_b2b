import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function RMA() {
  const rmaRequests = [
    { id: "RMA-001", product: "محصول ۱", reason: "معیوب", status: "در بررسی", date: "۱۴۰۲/۱۰/۱۰" },
    { id: "RMA-002", product: "محصول ۲", reason: "سالم نیست", status: "تایید شده", date: "۱۴۰۲/۱۰/۸" },
    { id: "RMA-003", product: "محصول ۳", reason: "برگشت", status: "نقل شده", date: "۱۴۰۲/۱۰/۵" },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">خدمات پس از فروش</h1>
        <p className="text-muted-foreground mt-1">مدیریت درخواست‌های بازگشت و تعویض</p>
      </div>

      <Tabs defaultValue="requests" className="w-full">
        <TabsList>
          <TabsTrigger value="requests">درخواست‌ها</TabsTrigger>
          <TabsTrigger value="returns">برگشت‌ها</TabsTrigger>
          <TabsTrigger value="analytics">تحلیل</TabsTrigger>
        </TabsList>

        <TabsContent value="requests">
          <Card>
            <CardHeader>
              <CardTitle>درخواست‌های RMA</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-right py-3 px-4 font-semibold">شماره</th>
                      <th className="text-right py-3 px-4 font-semibold">محصول</th>
                      <th className="text-right py-3 px-4 font-semibold">دلیل</th>
                      <th className="text-right py-3 px-4 font-semibold">وضعیت</th>
                      <th className="text-right py-3 px-4 font-semibold">تاریخ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rmaRequests.map((rma) => (
                      <tr key={rma.id} className="border-b border-border hover:bg-accent">
                        <td className="py-4 px-4">{rma.id}</td>
                        <td className="py-4 px-4">{rma.product}</td>
                        <td className="py-4 px-4">{rma.reason}</td>
                        <td className="py-4 px-4">
                          <span className={
                            rma.status === "تایید شده" ? "text-green-600" :
                            rma.status === "نقل شده" ? "text-blue-600" :
                            "text-orange-600"
                          }>
                            {rma.status}
                          </span>
                        </td>
                        <td className="py-4 px-4">{rma.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="returns">
          <Card>
            <CardHeader>
              <CardTitle>برگشت‌های محصول</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">رهگیری برگشت‌های محصول</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>تحلیل بازگشت‌ها</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">کل RMA</p>
                  <p className="text-2xl font-bold">۴۵</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">نرخ بازگشت</p>
                  <p className="text-2xl font-bold">۲.۳%</p>
                </div>
                <div className="p-4 bg-accent rounded-lg">
                  <p className="text-sm text-muted-foreground">زمان میانگین</p>
                  <p className="text-2xl font-bold">۵ روز</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
