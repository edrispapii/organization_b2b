import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export function Channels() {
  const channels = [
    { id: 1, name: "خرد‌فروشی", type: "Retail", margin: "۳۰%", active: true },
    { id: 2, name: "عمده‌فروشی", type: "Wholesale", margin: "۲۰%", active: true },
    { id: 3, name: "نمایندگی", type: "Dealer", margin: "۱۵%", active: true },
  ]

  return (
    <div className="p-8 space-y-6" dir="rtl">
      <div>
        <h1 className="text-3xl font-bold">کانال‌های فروش</h1>
        <p className="text-muted-foreground mt-1">مدیریت کانال‌های توزیع مختلف</p>
      </div>

      <Tabs defaultValue="channels" className="w-full">
        <TabsList>
          <TabsTrigger value="channels">کانال‌ها</TabsTrigger>
          <TabsTrigger value="partners">شرکای توزیع</TabsTrigger>
          <TabsTrigger value="performance">عملکرد</TabsTrigger>
        </TabsList>

        <TabsContent value="channels">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {channels.map((channel) => (
              <Card key={channel.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{channel.name}</CardTitle>
                    {channel.active ? (
                      <Badge variant="default">فعال</Badge>
                    ) : (
                      <Badge variant="outline">غیرفعال</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">نوع:</span>
                    <span>{channel.type}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">حاشیه سود:</span>
                    <span className="font-semibold">{channel.margin}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="partners">
          <Card>
            <CardHeader>
              <CardTitle>شرکای توزیع</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 border border-border rounded-lg">
                  <p className="font-medium">شریک الف - خرد‌فروشی</p>
                  <p className="text-sm text-muted-foreground">۵۰ فروشگاه</p>
                </div>
                <div className="p-4 border border-border rounded-lg">
                  <p className="font-medium">شریک ب - عمده‌فروشی</p>
                  <p className="text-sm text-muted-foreground">۲۰ نقطه توزیع</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>عملکرد کانال‌ها</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">نمودارهای عملکرد کانال‌های فروش</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
